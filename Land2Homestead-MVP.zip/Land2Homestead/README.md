# Land2Homestead MVP

A free, responsive starter web app for Land2Homestead.

## Run it
Open `index.html` in a browser. No server or paid service is required for this MVP.

## Next upgrades
1. Connect a real database for saved properties.
2. Add user accounts.
3. Connect property/public-record data sources.
4. Add a paid report checkout.
5. Generate downloadable property reports.
6. Deploy to free-tier hosting.
